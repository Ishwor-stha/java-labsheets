import java.util.*;
public class App {
    public static void main(String[] args)  {

        Scanner sc=new Scanner(System.in);
        System.out.print("Enter the 1st integer:");
        int num1=sc.nextInt();
        System.out.print("Enter the 2nd integer:");
        int num2=sc.nextInt();
        System.out.println("The sum of two integer is "+(num1+num2));
        System.out.println("The difference of two integer is "+(num1-num2));
	System.out.println("The product of two integer is "+(num1*num2));
	System.out.println("The Average of two integer is "+((double)(num1+num2)/2.0));  
	if(num1>num2){
	System.out.println("Max integer "+num1);
	}
	else{
	System.out.println("Max integer "+num2);
	}
	if(num2<num1){
	System.out.println("Min integer "+num2);
	}
	else{
	System.out.println("Min integer"+num1);
	} 
        
               
        
    }
         

}

