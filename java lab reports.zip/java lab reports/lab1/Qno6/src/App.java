import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Input distance in meters
        System.out.print("Enter distance (in meters): ");
        double distance = sc.nextDouble();

        // Input time in hours, minutes, and seconds
        System.out.print("Enter time (hours): ");
        int hours = sc.nextInt();
        System.out.print("Enter time (minutes): ");
        int minutes = sc.nextInt();
        System.out.print("Enter time (seconds): ");
        int seconds = sc.nextInt();

        // Convert time to seconds
        int totalTimeInSeconds = (hours * 3600) + (minutes * 60) + seconds;

        // Calculate speed in meters per second
        double speedMps = distance / totalTimeInSeconds;

        // Calculate speed in kilometers per hour
        double speedKph = (distance / 1000) / (totalTimeInSeconds / 3600.0);

        // Calculate speed in miles per hour
        double speedMph = (distance / 1609.34) / (totalTimeInSeconds / 3600.0);

        // Display the speeds
        System.out.println("Speed:");
        System.out.println("Meters per second: " + speedMps);
        System.out.println("Kilometers per hour: " + speedKph);
        System.out.println("Miles per hour: " + speedMph);

        
    }
}

