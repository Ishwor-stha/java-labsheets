import java.util.*;
public class App {
    public static void main(String[] args)  {

        Scanner sc=new Scanner(System.in);
        System.out.print("Enter the temperature in Farenheit:");
        double f=sc.nextDouble();
        double c=(f-32)*5/9;
    	System.out.println("The temperature conversion form "+f+" Farenhight"+" to" +" celcius is "+c);
    }
         

}

