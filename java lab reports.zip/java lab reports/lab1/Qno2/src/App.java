import java.util.*;
public class App {
    public static void main(String[] args)  {

        Scanner sc=new Scanner(System.in);
        System.out.print("Enter the length in inch:");
        double inch=sc.nextDouble();
        System.out.println("The length from "+ inch+" inch"+" to meter is "+(inch*0.0254));
        
    }
         

}

