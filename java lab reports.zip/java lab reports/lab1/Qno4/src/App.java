import java.util.*;
public class App {
    public static void main(String[] args)  {

        Scanner sc=new Scanner(System.in);
        
        System.out.print("Enter the time on minutes:");
        int minutes=sc.nextInt();
        int year=minutes/(60*24*365);//minute/60=hour, hour*24==day, day*365==year
        int y=minutes%(60*24*365);
        int days=y/(1440);
        System.out.println(minutes+" minute is approximately "+ year+" year "+"and " + days+" days");
        
        				
        
               
        
    }
         

}

