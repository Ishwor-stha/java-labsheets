import java.util.*;
public class App {
    public static void main(String[] args)  {

        Scanner sc=new Scanner(System.in);
        System.out.print("Enter the weight in pounds:");
        double weight=sc.nextDouble();
        System.out.print("Enter the height in inch:");
        double height=sc.nextDouble();
        double bmi=(weight/(height*height))*703;
        System.out.println("You BMI is "+bmi);
        
        
        
    }
         

}

