import java.util.*;
public class App {
    public static void main(String[] args)  {

        Scanner sc=new Scanner(System.in);
        System.out.print("Enter the integer number:");
        int num=sc.nextInt();
        int sum=0;
        double count=0.0;
        System.out.println("Natural number up to "+num+" :");
        for(int i=1;i<=num;i++){
        	sum=sum+i;
        	count++;
        	System.out.print(i+"\t");
        	
        
        
        }
        System.out.println();
        System.out.println();
        double average=(double)(sum/count);
        
        System.out.println("The sum up to "+ num+" number is "+sum+" and the average is "+average);
        
        
        
    }
         

}
        

