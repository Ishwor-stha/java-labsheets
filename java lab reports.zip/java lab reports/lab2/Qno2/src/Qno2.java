import java.util.Scanner;

public class Qno2 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter the floating number:");
        double num=sc.nextDouble();
        if(num==0){
            System.out.println("The given number is zero.");

        }
        else if(num>0){
            System.out.println("The given number is positive");
        }else{
            System.out.println("The given number is negative");
        }
    }
    
}
