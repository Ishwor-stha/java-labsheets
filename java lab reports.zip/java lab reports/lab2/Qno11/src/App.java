import java.util.*;
public class App {
    public static void main(String[] args)  {

        Scanner sc=new Scanner(System.in);
        System.out.print("Enter a first number:");
        double firstNum=sc.nextDouble();
        System.out.print("Enter operator ie(+,-,/,*):");
        String choice=sc.next();
         System.out.print("Enter a Second number:");
        double secondNum=sc.nextDouble();
        switch(choice){
        
        	case "+":
        	System.out.println("Addition of two number is "+(firstNum+secondNum));
        	break;
        	case "-":
        	System.out.println("Subtraction of two number is "+(firstNum-secondNum));
        	break;
        	case "*":
        	System.out.println("Multiplication of two number is  "+(firstNum*secondNum));
        	break;
        	case "/":
        	System.out.println("Division of two number is "+(firstNum+secondNum));
        	break;
        	default:
        		System.out.println("Invalid operator ");
        
        
        
        
        
        
        
        
        }
       
       
       
       
    }
         

}

