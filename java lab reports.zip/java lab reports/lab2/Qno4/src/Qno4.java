import java.util.Scanner;

public class Qno4 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
	System.out.println("Enter a character : ");
	String character=sc.next().toLowerCase();
	char ch=character.charAt(0);
	if(character.length()>1){
		System.out.println("Error");
	
	} 		
	else if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u')
	{
	System.out.println("Entered character "+ch+" is  Vowel"); 
	}
	else if((ch>='a'&&ch<='z'))
		{
		System.out.println("Entered character "+ch+" is Consonant");
		}
	else{
		System.out.println("Error");
	}
	
	
	
	
    }

}
        
        
        
        
        
        
        
        
        
        
        
        
        

        
