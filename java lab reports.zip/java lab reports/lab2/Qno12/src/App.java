import java.util.*;
public class App {
    public static void main(String[] args)  {

        Scanner sc=new Scanner(System.in);
        System.out.println("choose a number to find area of:");
        
        System.out.println("1: circle");//pi *r*r
        System.out.println("2: square");//a*a
        System.out.println("3: rectangle");//l*w
        System.out.println("4: triangle");//(1/2)*b*h
        int choice=sc.nextInt();
        double pi=3.14;
       
        
        switch(choice){
        
        	case 1:
        	System.out.print("Enter the radidus:");
        	double r=sc.nextDouble();
        	System.out.println("The area of circle is: "+(pi*(r*r)));
        	break;
        	
        	
        	case 2:
        	System.out.print("Enter the length of side:");
        	double a=sc.nextDouble();
        	System.out.println("The area of square is: "+(a*a));
        	
        	break;
        	
        	
        	case 3:
        	System.out.print("Enter the length:");
        	double l=sc.nextDouble();
        	System.out.print("Enter the breadth:");
        	double b=sc.nextDouble();
        	System.out.println("The area of rectangle is: "+(l*b));
        	break;
        	
        	
        	case 4:
        	System.out.print("Enter the breadth:");
        	double br=sc.nextDouble();
        	System.out.print("Enter the height:");
        	double h=sc.nextDouble();
        	System.out.println("The area of triangle is: "+((1.0/2.0)*br*h));
        	break;

        	default:
        		System.out.println("Invalid choice ");
        
        }
       
       
       
       
    }
         

}
        	
        	
        	
        	
        	
        
        
        
        
        
        
        

