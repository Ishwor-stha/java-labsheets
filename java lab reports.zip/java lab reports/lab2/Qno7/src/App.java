import java.util.*;
public class App {
    public static void main(String[] args)  {

        Scanner sc=new Scanner(System.in);
        System.out.print("Enter the integer:");
        int num=sc.nextInt();
        System.out.println("Displaying  odd number up to "+num);	
        int sum=0;
        for(int i=1;i<=num;i++){
        
        	if(i%2!=0){
        		System.out.print(i+" \t");
        		sum=sum+i;
        	
        	}
        
        
        }
        
        System.out.println("\nThe sum of odd number up to "+num+" is "+sum);	
   
               
        
    }
         

}

