import java.util.Scanner;

public class Qno9 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a Sentence: ");
        String sentence = scanner.nextLine();
        int vowel = 0;
        int consonant = 0;
        int digit = 0;
        int other = 0;

        for (int i = 0; i < sentence.length(); i++) {
            char c = sentence.charAt(i);

            if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u' ||
                c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U') {
                vowel++;
            } else if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')) {
                consonant++;
            } else if (c >= '0' && c <= '9') {
                digit++;
            } else {
                other++;
            }
        }

        System.out.println("Vowels: " + vowel);
        System.out.println("Consonants: " + consonant);
        System.out.println("Digits: " + digit);
        System.out.println("Other characters: " + other);

      
    }
}

