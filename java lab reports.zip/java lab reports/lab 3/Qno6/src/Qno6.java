import java.util.Scanner;

public class Qno6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input matrix dimensions
        System.out.print("Enter the number of rows: ");
        int numRows = scanner.nextInt();
        System.out.print("Enter the number of columns: ");
        int numCols = scanner.nextInt();

        // Create the original matrix
        int[][] originalMatrix = new int[numRows][numCols];

        // Input matrix elements
        System.out.println("Enter the elements of the matrix:");
        for (int i = 0; i < numRows; i++) {
            for (int j = 0; j < numCols; j++) {
            System.out.print("("+(i+1)+(",")+(j+1)+")");
                originalMatrix[i][j] = scanner.nextInt();
            }
        }

        // Transpose the matrix and print the result
        System.out.println("Transposed Matrix:");
        for (int j = 0; j < numCols; j++) {
            for (int i = 0; i < numRows; i++) {
                System.out.print(originalMatrix[i][j] + " ");
            }
            System.out.println(); // Move to the next line for the next column
        }

    
    }
}

