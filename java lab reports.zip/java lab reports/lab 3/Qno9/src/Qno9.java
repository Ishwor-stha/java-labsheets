import java.util.Scanner;

public class Qno9 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a string: ");
        String inputString = scanner.nextLine();

        // Check if the string contains the specified sequence
        String Check = "and ";
        boolean containsAnd = inputString.contains(Check);

        if (containsAnd) {
            System.out.println(containsAnd);
        } else {
            System.out.println("false");
        }

        
    }
}

