import java.util.Scanner;

public class Qno6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input matrix dimensions
        System.out.print("Enter a String: ");
        String str = scanner.nextLine();
        System.out.print("Enter the Index  of character in a String: ");
        int index = scanner.nextInt()-1;
         System.out.println("The character in a index "+(index+1)+" is "+str.charAt(index));
        

        
        
        }

    
    }


