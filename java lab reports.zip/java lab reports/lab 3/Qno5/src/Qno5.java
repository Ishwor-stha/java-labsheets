import java.util.Scanner;

public class Qno5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input the number of rows and columns for the matrix
        System.out.print("Enter the number of rows: ");
        int numRows = scanner.nextInt();
        System.out.print("Enter the number of columns: ");
        int numCols = scanner.nextInt();

        // Create the matrix with the specified dimensions
        int[][] matrix = new int[numRows][numCols];

        // Input the elements of the matrix
        System.out.println("Enter the elements of the matrix:");
        for (int i = 0; i < numRows; i++) {
            for (int j = 0; j < numCols; j++) {
            System.out.print("("+(i+1)+","+(j+1)+"): ");
                matrix[i][j] = scanner.nextInt();
            }
        }

        // Calculate and display the sum of each row
        System.out.println("Sum of each row:");
        for (int i = 0; i < numRows; i++) {
            int rowSum = 0;
            for (int j = 0; j < numCols; j++) {
                rowSum += matrix[i][j];
            }
            System.out.println("Row " + (i + 1) + ": " + rowSum);
        }

        // Calculate and display the sum of each column
        System.out.println("Sum of each column:");
        for (int j = 0; j < numCols; j++) {
            int colSum = 0;
            for (int i = 0; i < numRows; i++) {
                colSum += matrix[i][j];
            }
            System.out.println("Column " + (j + 1) + ": " + colSum);
        }

       
    }
}

